import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,datetime,os,json,base64,plugintools
import GoDev
import xbmcvfs,zipfile
import xml.etree.ElementTree as ElementTree
reload(sys)
sys.setdefaultencoding('utf8')
SKIN_VIEW_FOR_MOVIES="515"
addonDir = plugintools.get_runtime_path()
global kontroll
background = "YmFja2dyb3VuZC5wbmc=" #background.png
defaultlogo = "ZGVmYXVsdGxvZ28ucG5n" #defaultlogo.png
hometheater = "aG9tZXRoZWF0ZXIuanBn"
noposter = "bm9wb3N0ZXIucG5n"
theater = "dGhlYXRlci5qcGc="
addonxml = "YWRkb24ueG1s"
addonpy = "ZGVmYXVsdC5weQ=="
icon = "aWNvbi5wbmc="
fanart = "ZmFuYXJ0LmpwZw=="
message = "VU5BVVRIT1JJWkVEIEVESVQgT0YgQURET04h"
def run():
	global pnimi
	global televisioonilink
	global filmilink
	global andmelink
	global lehekylg
	global LOAD_LIVE
	global vanemalukk
	
	kasutajanimi=plugintools.get_setting(get_live("VXNlcm5hbWU="))
	salasona=plugintools.get_setting(vod_channels("UGFzc3dvcmQ="))
	if not kasutajanimi or not salasona:
		plugintools.open_settings_dialog()
		kasutajanimi=plugintools.get_setting(get_live("VXNlcm5hbWU="))
		salasona=plugintools.get_setting(vod_channels("UGFzc3dvcmQ="))
		
	vanemalukk=plugintools.get_setting(sync_data("UGFyZW50YWxMb2Nr"))
	lehekylg=get_live("aHR0cDovL2NsaWVudHBvcnRhbC5saW5r")
	pordinumber=get_live("ODA4MA==")
	pnimi=get_live("UmFwaWRJUFRW")
	LOAD_LIVE = os.path.join( plugintools.get_runtime_path() , get_live("cmVzb3VyY2Vz") , vod_channels("bWVkaWE=") )
	plugintools.log(pnimi+get_live("U3RhcnRpbmcgdXA="))
	televisioonilink = get_live("JXM6JXMvZW5pZ21hMi5waHA/dXNlcm5hbWU9JXMmcGFzc3dvcmQ9JXMmdHlwZT1nZXRfbGl2ZV9jYXRlZ29yaWVz")%(lehekylg,pordinumber,kasutajanimi,salasona)
	filmilink = vod_channels("JXM6JXMvZW5pZ21hMi5waHA/dXNlcm5hbWU9JXMmcGFzc3dvcmQ9JXMmdHlwZT1nZXRfdm9kX2NhdGVnb3JpZXM=")%(lehekylg,pordinumber,kasutajanimi,salasona)
	andmelink = vod_channels("JXM6JXMvcGxheWVyX2FwaS5waHA/dXNlcm5hbWU9JXMmcGFzc3dvcmQ9JXM=")%(lehekylg,pordinumber,kasutajanimi,salasona)
	if get_live("UmFwaWRJUFRW") not in open(addonDir+"/"+sync_data("YWRkb24ueG1s")).read():
	   check_user()
	   
	params = plugintools.get_params()
	if params.get("action") is None:
		peamenyy(params)
	else:
		action = params.get("action")
		exec action+"(params)"
	plugintools.close_item_list()

def peamenyy(params):
	plugintools.log(pnimi+vod_channels("TWFpbiBNZW51")+repr(params))
	load_channels()
	if not lehekylg:
	   plugintools.open_settings_dialog()
	channels = kontroll()
	if channels == 1:
	   plugintools.log(pnimi+vod_channels("TG9naW4gU3VjY2Vzcw=="))
	   plugintools.add_item( action=vod_channels("ZXhlY3V0ZV9haW5mbw=="),  title=vod_channels("TXkgQWNjb3VudA==") , thumbnail=os.path.join(LOAD_LIVE,vod_channels("bXlhY2MucG5n")) , fanart=os.path.join(LOAD_LIVE,vod_channels("YmFja2dyb3VuZC5wbmc=")) , folder=True )
	   plugintools.add_item( action=vod_channels("c2VjdXJpdHlfY2hlY2s="),  title=vod_channels("TGl2ZSBUVg==") , thumbnail=os.path.join(LOAD_LIVE,vod_channels("bGl2ZXR2LnBuZw==")) , fanart=os.path.join(LOAD_LIVE,vod_channels("YmFja2dyb3VuZC5wbmc=")) , folder=True )
	   plugintools.add_item( action=vod_channels("ZGV0ZWN0X21vZGlmaWNhdGlvbg=="), title=vod_channels("Vk9E") , thumbnail=os.path.join(LOAD_LIVE,vod_channels("dm9kLnBuZw==")) , fanart=os.path.join(LOAD_LIVE,vod_channels("YmFja2dyb3VuZC5wbmc=")) , folder=True )
	   plugintools.add_item( action=vod_channels("bGljZW5zZV9jaGVjaw=="), title=vod_channels("U2V0dGluZw==") , thumbnail=os.path.join(LOAD_LIVE,vod_channels("c2V0dGluZ3MucG5n")) , fanart=os.path.join(LOAD_LIVE,vod_channels("YmFja2dyb3VuZC5wbmc=") ), folder=False )
	   plugintools.add_item( action=vod_channels("Y2xyX2NjaA=="), title=vod_channels("Q2xlYXIgQ2FjaGU=") , thumbnail=os.path.join(LOAD_LIVE,vod_channels("Y2FjaGUucG5n")) , fanart=os.path.join(LOAD_LIVE,vod_channels("YmFja2dyb3VuZC5wbmc=") ), folder=False )
	   plugintools.set_view( plugintools.LIST )
	else:
	   plugintools.log(pnimi+vod_channels("TG9naW4gZmFpbGVk"))
	   plugintools.message(vod_channels("TG9naW4gZmFpbGVk"), vod_channels("UG9zc2libGUgcmVhc29uczogV3JvbmcgVXNlcm5hbWUgb3IgUGFzc3dvcmQuICAgICAgICAgICAgICAgUGxlYXNlIHJlY29uZmlndXJlICVzIHBsdWdpbiB3aXRoIGNvcnJlY3QgZGV0YWlscyE=")%(pnimi))
	   plugintools.open_settings_dialog()
	   exit()

def license_check(params):
	plugintools.log(pnimi+get_live("U2V0dGluZ3MgbWVudQ==")+repr(params))
	plugintools.open_settings_dialog()
def security_check(params):
	plugintools.log(pnimi+sync_data("TGl2ZSBNZW51")+repr(params))
	request = urllib2.Request(televisioonilink, headers={"Accept" : "*/*"})
	u = urllib2.urlopen(request)
	tree = ElementTree.parse(u)
	rootElem = tree.getroot()
	for channel in tree.findall(sync_data("Y2hhbm5lbA==")):
		kanalinimi = channel.find(get_live("dGl0bGU=")).text
		kanalinimi = base64.b64decode(kanalinimi)
		kategoorialink = channel.find(vod_channels("cGxheWxpc3RfdXJs")).text
		plugintools.add_item( action=get_live("c3RyZWFtX3ZpZGVv"), title=kanalinimi , url=kategoorialink , thumbnail=os.path.join(LOAD_LIVE,vod_channels("bGl2ZXR2LnBuZw==")) , fanart=os.path.join(LOAD_LIVE,sync_data("dGhlYXRlci5qcGc=")) , folder=True )
	plugintools.set_view( plugintools.LIST )
def detect_modification(params):
	plugintools.log(pnimi+vod_channels("Vk9EIE1lbnUg")+repr(params))
	request = urllib2.Request(filmilink, headers={"Accept" : "*/*"})
	u = urllib2.urlopen(request)
	tree = ElementTree.parse(u)
	rootElem = tree.getroot()
	for channel in tree.findall(sync_data("Y2hhbm5lbA==")):
		filminimi = channel.find(get_live("dGl0bGU=")).text
		filminimi = base64.b64decode(filminimi)
		filminimi = filminimi.encode("utf-8")
		kategoorialink = channel.find(vod_channels("cGxheWxpc3RfdXJs")).text
		engma = sync_data("c2NhdF9pZA=="), sync_data("Z2V0X3ZvZF9zY2F0ZWdvcmllcw==")
		if any(stlru in kategoorialink for stlru in engma):
			plugintools.add_item( action=vod_channels("c3ViX21vZGlmaWNhdGlvbg=="), title=filminimi , url=kategoorialink , thumbnail=os.path.join(LOAD_LIVE,vod_channels("dm9kLnBuZw==")) , fanart=os.path.join(LOAD_LIVE,sync_data("dGhlYXRlci5qcGc=")) , folder=True )
		else:
			if filminimi == sync_data("QWxs"):
				continue
			plugintools.add_item( action=vod_channels("Z2V0X215YWNjb3VudA=="), title=filminimi , url=kategoorialink , thumbnail=os.path.join(LOAD_LIVE,vod_channels("dm9kLnBuZw==")) , fanart=os.path.join(LOAD_LIVE,sync_data("dGhlYXRlci5qcGc=")) , folder=True )
	plugintools.set_view( plugintools.LIST )
	
def sub_modification(params):
	plugintools.log(pnimi+vod_channels("U1VCVk9EIE1lbnUg")+repr(params))
	purl = params.get(get_live("dXJs"))
	request = urllib2.Request(purl, headers={"Accept" : "*/*"})
	u = urllib2.urlopen(request)
	tree = ElementTree.parse(u)
	rootElem = tree.getroot()
	for channel in tree.findall(sync_data("Y2hhbm5lbA==")):
		filminimi = channel.find(get_live("dGl0bGU=")).text
		filminimi = base64.b64decode(filminimi)
		filminimi = filminimi.encode("utf-8")
		kategoorialink = channel.find(vod_channels("cGxheWxpc3RfdXJs")).text
		plugintools.add_item( action=vod_channels("Z2V0X215YWNjb3VudA=="), title=filminimi , url=kategoorialink , thumbnail=os.path.join(LOAD_LIVE,vod_channels("dm9kLnBuZw==")) , fanart=os.path.join(LOAD_LIVE,sync_data("dGhlYXRlci5qcGc=")) , folder=True )
	plugintools.set_view( plugintools.LIST )
	
def stream_video(params):
	plugintools.log(pnimi+sync_data("TGl2ZSBDaGFubmVscyBNZW51IA==")+repr(params))
	if get_live("UmFwaWRJUFRW") not in open(addonDir+"/"+sync_data("YWRkb24ueG1s")).read():
	   check_user()   
	if vanemalukk == "true":
		pealkiri = params.get(sync_data("dGl0bGU="))
		vanema_lukk(pealkiri)
	url = params.get(get_live("dXJs"))
	request = urllib2.Request(url, headers={"Accept" : "*/*"})
	u = urllib2.urlopen(request)
	tree = ElementTree.parse(u)
	rootElem = tree.getroot()
	for channel in tree.findall(sync_data("Y2hhbm5lbA==")):
		kanalinimi = channel.find(get_live("dGl0bGU=")).text
		kanalinimi = base64.b64decode(kanalinimi)
		kanalinimi = kanalinimi.partition("[")
		striimilink = channel.find(get_live("c3RyZWFtX3VybA==")).text
		pilt = channel.find(vod_channels("ZGVzY19pbWFnZQ==")).text
		kava = kanalinimi[1]+kanalinimi[2]
		kava = kava.partition("]")
		kava = kava[2]
		kava = kava.partition("   ")
		kava = kava[2]
		shou = get_live("W0NPTE9SIHN0ZWVsYmx1ZV0lcyBbL0NPTE9SXQ==")%(kanalinimi[0])+"- [COLOR firebrick]" + kava + "[/COLOR]"
		kirjeldus = channel.find(sync_data("ZGVzY3JpcHRpb24=")).text
		if kirjeldus:
		   kirjeldus = base64.b64decode(kirjeldus)
		   nyyd = kirjeldus.partition("(")
		   nyyd = sync_data("Tk9XOiA=") +nyyd[0]
		   jargmine = kirjeldus.partition(")\n")
		   jargmine = jargmine[2].partition("(")
		   jargmine = sync_data("TkVYVDog") +jargmine[0]
		   kokku = nyyd+jargmine
		else:
		   kokku = ""
		if pilt:
		   plugintools.add_item( action=sync_data("cnVuX2Nyb25qb2I="), title=shou , url=striimilink, thumbnail=pilt, plot=kokku, fanart=os.path.join(LOAD_LIVE,vod_channels("aG9tZXRoZWF0ZXIuanBn")), extra="", isPlayable=True, folder=False )
		else:
		   plugintools.add_item( action=sync_data("cnVuX2Nyb25qb2I="), title=shou , url=striimilink, thumbnail=os.path.join(LOAD_LIVE,sync_data("ZGVmYXVsdGxvZ28ucG5n")) , plot=kokku, fanart=os.path.join(LOAD_LIVE,sync_data("aG9tZXRoZWF0ZXIuanBn")) , extra="", isPlayable=True, folder=False )
	plugintools.set_view( plugintools.EPISODES )
	xbmc.executebuiltin(vod_channels("Q29udGFpbmVyLlNldFZpZXdNb2RlKDUwMyk="))
def get_myaccount(params):
	plugintools.log(pnimi+get_live("Vk9EIGNoYW5uZWxzIG1lbnUg")+repr(params))
	if vanemalukk == "true":
		pealkiri = params.get(sync_data("dGl0bGU="))
		vanema_lukk(pealkiri)
	purl = params.get(get_live("dXJs"))
	request = urllib2.Request(purl, headers={"Accept" : "*/*"})
	u = urllib2.urlopen(request)
	tree = ElementTree.parse(u)
	rootElem = tree.getroot()
	for channel in tree.findall(sync_data("Y2hhbm5lbA==")):
		pealkiri = channel.find(get_live("dGl0bGU=")).text
		pealkiri = base64.b64decode(pealkiri)
		pealkiri = pealkiri.encode("utf-8")
		striimilink = channel.find(sync_data("c3RyZWFtX3VybA==")).text
		pilt = channel.find(sync_data("ZGVzY19pbWFnZQ==")).text
		kirjeldus = channel.find(vod_channels("ZGVzY3JpcHRpb24=")).text
		if kirjeldus:
			kirjeldus = base64.b64decode(kirjeldus)
			kirjeldus = kirjeldus.encode("utf-8")
		if pilt:
			plugintools.add_item( action="restart_service", title=pealkiri , url=striimilink, thumbnail=pilt, plot=kirjeldus, fanart=os.path.join(LOAD_LIVE,"theater.jpg") , extra="", isPlayable=True, folder=False )
		else:
			plugintools.add_item( action="restart_service", title=pealkiri , url=striimilink, thumbnail=os.path.join(LOAD_LIVE,"noposter.png"), plot=kirjeldus, fanart=os.path.join(LOAD_LIVE,"theater.jpg"), extra="", isPlayable=True, folder=False )
		plugintools.set_view( plugintools.MOVIES )
		xbmc.executebuiltin('Container.SetViewMode(515)')
	

def clr_cch(params):
	choice = xbmcgui.Dialog().yesno('Clear your Cache?', 'This will Refresh your Live Events', 'It can help with Buffering issues also','If you have any issues, Make sure you are in our forum - Were here to help.', nolabel='Cancel',yeslabel='Delete')
	if choice == 1:
		GoDev.Wipe_Cache()
		GoDev.Remove_Textures()

def run_cronjob(params):
	kasutajanimi=plugintools.get_setting(get_live("VXNlcm5hbWU="))
	salasona=plugintools.get_setting(vod_channels("UGFzc3dvcmQ="))
	lopplink = params.get(vod_channels("dXJs"))
	lopplink = lopplink.replace(vod_channels("JXVzZXJuYW1l"), vod_channels("a2FzdXRhamFuaW1p"))
	lopplink = lopplink.replace(vod_channels("JXBhc3N3b3Jk"), vod_channels("c2FsYXNvbmE="))
	stvypo = plugintools.get_setting(sync_data("U3RyZWFtX1R5cGU="))
	if stvypo == "1":
		lopplink = lopplink.replace(vod_channels("LnRz"), vod_channels("Lm0zdTg="))
	listitem = xbmcgui.ListItem(path=lopplink)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)

def sync_data(channel):
	video = base64.b64decode(channel)
	return video

def restart_service(params):
	lopplink = params.get(vod_channels("dXJs"))
	plugintools.play_resolved_url( lopplink )

def grab_epg():
	req = urllib2.Request(andmelink)
	req.add_header(sync_data("VXNlci1BZ2VudA==") , vod_channels("S29kaSBwbHVnaW4gYnkgUmFwaWRJUFRW"))
	response = urllib2.urlopen(req)
	link=response.read()
	jdata = json.loads(link.decode('utf8'))
	response.close()
	if jdata:
	   plugintools.log(pnimi+sync_data("amRhdGEgbG9hZGVkIA=="))
	   return jdata
	   
def kontroll():
	randomstring = grab_epg()
	kasutajainfo = randomstring[sync_data("dXNlcl9pbmZv")]
	kontroll = kasutajainfo[get_live("YXV0aA==")]
	return kontroll
	
def get_live(channel):
	video = base64.b64decode(channel)
	return video
	
def execute_ainfo(params):
	plugintools.log(pnimi+get_live("TXkgYWNjb3VudCBNZW51IA==")+repr(params))
	andmed = grab_epg()
	kasutajaAndmed = andmed[sync_data("dXNlcl9pbmZv")]
	seis = kasutajaAndmed[get_live("c3RhdHVz")]
	aegub = kasutajaAndmed[sync_data("ZXhwX2RhdGU=")]
	if aegub:
	   aegub = datetime.datetime.fromtimestamp(int(aegub)).strftime('%d/%m/%Y %H:%M')
	else:
	   aegub = vod_channels("TmV2ZXI=")
	leavemealone = kasutajaAndmed[get_live("bWF4X2Nvbm5lY3Rpb25z")]
	polarbears = kasutajaAndmed[sync_data("dXNlcm5hbWU=")]
	plugintools.add_item( action="",   title=sync_data("W0NPTE9SID0gd2hpdGVdVXNlcjogWy9DT0xPUl0=")+polarbears , thumbnail=os.path.join(LOAD_LIVE,vod_channels("bXlhY2MucG5n")) , fanart=os.path.join(LOAD_LIVE,sync_data("YmFja2dyb3VuZC5wbmc=")) , folder=False )
	plugintools.add_item( action="",   title=sync_data("W0NPTE9SID0gd2hpdGVdU3RhdHVzOiBbL0NPTE9SXQ==")+seis , thumbnail=os.path.join(LOAD_LIVE,vod_channels("bXlhY2MucG5n")) , fanart=os.path.join(LOAD_LIVE,sync_data("YmFja2dyb3VuZC5wbmc=")) , folder=False )
	plugintools.add_item( action="",   title=get_live("W0NPTE9SID0gd2hpdGVdRXhwaXJlczogWy9DT0xPUl0=")+aegub , thumbnail=os.path.join(LOAD_LIVE,vod_channels("bXlhY2MucG5n")) , fanart=os.path.join(LOAD_LIVE,sync_data("YmFja2dyb3VuZC5wbmc=")) , folder=False )
	plugintools.add_item( action="",   title=vod_channels("W0NPTE9SID0gd2hpdGVdTWF4IGNvbm5lY3Rpb25zOiBbL0NPTE9SXQ==")+leavemealone , thumbnail=os.path.join(LOAD_LIVE,vod_channels("bXlhY2MucG5n")) , fanart=os.path.join(LOAD_LIVE,sync_data("YmFja2dyb3VuZC5wbmc=")) , folder=False )
	plugintools.set_view( plugintools.LIST )

def vanema_lukk(name):
	plugintools.log(pnimi+sync_data("UGFyZW50YWwgbG9jayA="))
	a = 'XXX', 'Adult', 'Adults','ADULT','ADULTS','adult','adults','Porn','PORN','porn','Porn','xxx'
	if any(s in name for s in a):
		xbmc.executebuiltin((u'XBMC.Notification("Parental Lock", "Channels may contain adult content", 2000)'))
		text = plugintools.keyboard_input(default_text="", title=get_live("UGFyZW50YWwgbG9jaw=="))
		if text == plugintools.get_setting(sync_data("UGFyZW50YWxDb2Rl")):
			return
		else:
			exit()
	else:
		name = ""

def check_user():
	plugintools.message(get_live("RVJST1I="),vod_channels("VU5BVVRIT1JJWkVEIEVESVQgT0YgQURET04h"))
	sys.exit()
	
def load_channels():
	statinfo = os.stat(LOAD_LIVE+"/"+get_live("YmFja2dyb3VuZC5wbmc="))

def vod_channels(channel):
	video = base64.b64decode(channel)
	return video
run()
